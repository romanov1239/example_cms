-- MySQL dump 10.13  Distrib 5.6.38, for Win32 (AMD64)
--
-- Host: 192.168.50.222    Database: yii-backend.loc
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `properties` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_unique` (`provider`,`client_id`),
  KEY `fk_user_account` (`user_id`),
  CONSTRAINT `fk_user_account` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;

--
-- Table structure for table `auth`
--

DROP TABLE IF EXISTS `auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-auth-user_id` (`user_id`),
  CONSTRAINT `fk-auth-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth`
--

/*!40000 ALTER TABLE `auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth` ENABLE KEYS */;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `max_acceleration` int(11) DEFAULT NULL,
  `max_speed` int(11) DEFAULT NULL,
  `max_hp` int(11) DEFAULT NULL,
  `speed_upgrade_step` int(11) DEFAULT NULL,
  `hp_upgrade_step` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (1,'Быстрая',20,20,20,2,2,'14783200_Alt03.jpg'),(2,'Средняя',3,15,25,2,2,NULL),(3,'Большая',2,12,30,1,5,NULL);
/*!40000 ALTER TABLE `car` ENABLE KEYS */;

--
-- Table structure for table `contest`
--

DROP TABLE IF EXISTS `contest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contest_start` datetime NOT NULL,
  `contest_end` datetime NOT NULL,
  `complete` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contest`
--

/*!40000 ALTER TABLE `contest` DISABLE KEYS */;
INSERT INTO `contest` VALUES (1,'2018-09-24 00:00:37','2018-09-30 00:00:37',1),(2,'2018-09-17 00:55:55','2018-09-23 23:55:55',1),(3,'2018-10-01 00:00:13','2018-10-07 23:55:13',0),(4,'2018-10-08 00:00:36','2018-10-14 23:55:36',0),(5,'2018-10-15 00:00:04','2018-10-21 23:55:04',0);
/*!40000 ALTER TABLE `contest` ENABLE KEYS */;

--
-- Table structure for table `gift`
--

DROP TABLE IF EXISTS `gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `group` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift`
--

/*!40000 ALTER TABLE `gift` DISABLE KEYS */;
INSERT INTO `gift` VALUES (1,1,'3213','First','14783200_Alt03.jpg','<p>fgsdgafdgsfdg</p>\r\n','sadfa');
/*!40000 ALTER TABLE `gift` ENABLE KEYS */;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enemy_damage_factor` int(11) DEFAULT NULL,
  `enemy_speed_factor` int(11) DEFAULT NULL,
  `healing_factor` int(11) DEFAULT NULL,
  `currency_factor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level`
--

/*!40000 ALTER TABLE `level` DISABLE KEYS */;
INSERT INTO `level` VALUES (1,1,1,1,NULL);
/*!40000 ALTER TABLE `level` ENABLE KEYS */;

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration`
--

/*!40000 ALTER TABLE `migration` DISABLE KEYS */;
INSERT INTO `migration` VALUES ('m000000_000000_base',1537952596),('m130524_201442_init',1537952599),('m140209_132017_init',1537957661),('m140403_174025_create_account_table',1537957661),('m180924_072926_create_gift_table',1537952599),('m180924_073151_create_user_table',1537952628),('m180924_073309_create_car_table',1537952628),('m180924_073529_create_user_car_table',1537952628),('m180924_074015_create_level_table',1537952628),('m180924_074332_create_race_table',1537952628),('m180924_075150_create_contest_table',1537952628),('m180924_075346_create_winner_table',1537952629),('m180924_075841_create_action_log_table',1537952629),('m180924_090520_add_currency_factor_column_to_level_table',1537952629),('m180927_093603_create_auth_table',1538040971),('m180927_102755_add_password_hash_column_to_user_table',1538044639),('m180927_141351_add_image_column_to_car_table',1538057639),('m181004_080349_add_user_car_id_to_action_log_table',1538640238),('m181004_080759_add_user_car_id_column_to_action_log_table',1538640494),('m181005_080742_drop_action_log_table',1538727230),('m181005_081010_create_user_log_table',1538727230),('m181005_081341_create_user_attr_change_log_table',1538727230),('m181005_081953_delete_user_car_id_column_from_user_log_table',1538727602),('m181005_095941_add_timestamp_column_to_winner_table',1538733611),('m181009_104051_create_user_admin_table',1539081661);
/*!40000 ALTER TABLE `migration` ENABLE KEYS */;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `user_auth` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;

--
-- Table structure for table `race`
--

DROP TABLE IF EXISTS `race`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `race` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `complete` tinyint(1) DEFAULT NULL,
  `start_timestamp` timestamp NULL DEFAULT NULL,
  `finish_timestamp` timestamp NULL DEFAULT NULL,
  `client_time` int(11) DEFAULT NULL,
  `user_car_id` int(11) DEFAULT NULL,
  `user_speed_level` int(11) DEFAULT NULL,
  `user_hp_level` int(11) DEFAULT NULL,
  `speed_max_level` int(11) DEFAULT NULL,
  `hp_min_level` int(11) DEFAULT NULL,
  `hp_max_level` int(11) DEFAULT NULL,
  `difficulty_level` int(11) DEFAULT NULL,
  `enemy_damage_factor` int(11) DEFAULT NULL,
  `enemy_speed_factor` int(11) DEFAULT NULL,
  `healing_factor` int(11) DEFAULT NULL,
  `currency_before` int(11) DEFAULT NULL,
  `currency_get` int(11) DEFAULT NULL,
  `currency_after` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-race-user_id` (`user_id`),
  KEY `idx-race-user_car_id` (`user_car_id`),
  CONSTRAINT `fk-race-user_car_id` FOREIGN KEY (`user_car_id`) REFERENCES `user_car` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-race-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `race`
--

/*!40000 ALTER TABLE `race` DISABLE KEYS */;
INSERT INTO `race` VALUES (22,1,1,'2005-07-13 01:10:35','2005-07-13 01:10:40',5,1,1,1,5,1,1,0,1,1,1,1,1,2),(23,1,NULL,'2005-07-13 01:10:35',NULL,NULL,1,1,1,NULL,NULL,NULL,1,NULL,NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `race` ENABLE KEYS */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `difficulty_level` int(11) NOT NULL,
  `auth_id` varchar(255) NOT NULL,
  `user_auth_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gift_id` int(11) NOT NULL,
  `is_banned` tinyint(1) DEFAULT NULL,
  `current_currency` int(11) DEFAULT NULL,
  `auth_key` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-user-gift_id` (`gift_id`),
  CONSTRAINT `fk-user-gift_id` FOREIGN KEY (`gift_id`) REFERENCES `gift` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Первый',1,'vk','123','1@1.ru',1,0,2,'','','',10,0,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

--
-- Table structure for table `user_admin`
--

DROP TABLE IF EXISTS `user_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_admin`
--

/*!40000 ALTER TABLE `user_admin` DISABLE KEYS */;
INSERT INTO `user_admin` VALUES (1,'admin','ZaeE04VoryFOwIeRfy4CTFFZd10imxIq','$2y$13$uEiHOU0mNo5jSSL91K5G1uXyqBEa35G1eVx36rSRtqfUTtAuhjxV.',NULL,'admin@123.ru',10,1539085076,1539085076),(4,'admin1','dhjCFbS5KSFjA87kMUTBW8--3PCvEgfU','$2y$13$Oz9UVCrVZcR72Sx17ySlLOjacmSIPC85cImzH8qdTWToaPNat2gsq',NULL,'admin1@123.ru',10,1539085699,1539085699),(5,'admin2','2qOFVGC8SiS08qkpUdrhsZ9nXOPADQCy','$2y$13$48b7/J.sbLP3BoleplS2QOZ//LEcLL1kxsqq2mnffxansmitagfx2',NULL,'admin2@123.ru',10,1539092812,1539092812),(6,'admin3','0MKdOYjEuItgBrYnFjpgydxB6KcQDFx2','$2y$13$fiWuWH86R0ERw2XbvKU7a.YJzrQ4vDOrZv0.9/uZUKIukx/dFN7Hy',NULL,'admin3@123.ru',10,1539092961,1539092961),(7,'admin6','MM6134ovYR61bwlDeg6FXrVDDFMCRVLg','$2y$13$Vk6mVYU4/2GakTr9ibRlou8JSPRAQri78u/ktKAIvmGH4MayTNlhW',NULL,'admin6@123.ru',10,1539099203,1539099203),(8,'admin7','aKksFbzEFy91_t2ANOuZLcWVV0VB64Yk','$2y$13$QYivnyozLJK46RRr8L8I7.8IhmuwH8XLzicAFgke2m5T53T1voTCq',NULL,'admin7@123.ru',10,1539099421,1539099421),(9,'admin8','DXuqrxXathgGXYKCR4nTlaBxvKrZTpgk','$2y$13$N0c/5xoTfmissCAgLeaWOuGwcU/.uvceeXr1CGLmbLlBeQOgVOqSG',NULL,'admin8@123.ru',10,1539099533,1539099533),(10,'admin9','ecMjFB2JYLdaBAZqEu-bDEKyrgke4LMW','$2y$13$DPSey8nFlOylVnOg1S/5U.o31j7fFYqmy4KIM0nFKCgPZikZKtbsu',NULL,'admin9@123.ru',10,1539099731,1539099731),(11,'admin10','pMTP6bQR0BzaCM79qKmRXr7vnCMyJ_WH','$2y$13$g3Fgtv/zaBxBuVeSBx9A3O1.SPE9jRRSXp9AM9t3fOyYhWPnrdTtq',NULL,'admin10@123.ru',10,1539099756,1539099756);
/*!40000 ALTER TABLE `user_admin` ENABLE KEYS */;

--
-- Table structure for table `user_attr_change_log`
--

DROP TABLE IF EXISTS `user_attr_change_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_attr_change_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL,
  `user_id` int(11) NOT NULL,
  `attr_name` varchar(255) NOT NULL,
  `value_before` int(11) NOT NULL,
  `value_after` int(11) NOT NULL,
  `criticallity_level` int(11) NOT NULL,
  `currency_amount` int(11) NOT NULL,
  `user_car_id` int(11) DEFAULT NULL,
  `event_text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_attr_change_log`
--

/*!40000 ALTER TABLE `user_attr_change_log` DISABLE KEYS */;
INSERT INTO `user_attr_change_log` VALUES (1,'2018-10-05 09:05:29',1,'user_currency',1,2,2,2,NULL,'Получение валюты за завершение гонки'),(2,'2018-10-05 09:05:53',1,'user_currency',1,2,2,2,NULL,'Получение валюты за завершение гонки'),(3,'2018-10-05 09:06:09',1,'user_currency',1,2,2,2,NULL,'Получение валюты за завершение гонки'),(4,'2018-10-05 09:11:13',1,'speed_level',1,2,2,2,1,'Прокачка параметраspeed_level'),(5,'2018-10-05 09:14:24',1,'speed_level',1,2,3,2,1,'Некорректное значение аттрибута \"speed_level\"!'),(6,'2018-10-05 09:14:25',1,'speed_level',1,2,3,2,1,'Некорректное значение аттрибута \"speed_level\"!'),(7,'2018-10-05 09:14:30',1,'speed_level',2,5,2,2,1,'Прокачка параметраspeed_level'),(8,'2018-10-05 09:23:03',1,'speed_level',2,5,3,2,2,'Некорректное значение аттрибута \"speed_level\"!'),(9,'2018-10-05 09:23:11',1,'speed_level',13,2,2,2,2,'Прокачка параметра speed_level'),(10,'2018-10-05 09:23:28',1,'speed_level',13,2,3,2,2,'Некорректное значение аттрибута \"speed_level\"!'),(11,'2018-10-05 09:26:57',1,'speed_level',13,2,3,2,2,'Некорректное значение аттрибута \"speed_level\"!'),(12,'2018-10-05 09:34:30',1,'hp_level',13,2,3,2,2,'Некорректное значение аттрибута \"hp_level\"!'),(13,'2018-10-05 09:34:40',1,'hp_level',15,2,2,2,2,'Прокачка параметра hp_level');
/*!40000 ALTER TABLE `user_attr_change_log` ENABLE KEYS */;

--
-- Table structure for table `user_car`
--

DROP TABLE IF EXISTS `user_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `speed_level` int(11) DEFAULT NULL,
  `hp_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-user_car-car_id` (`car_id`),
  KEY `idx-user_car-user_id` (`user_id`),
  CONSTRAINT `fk-user_car-car_id` FOREIGN KEY (`car_id`) REFERENCES `car` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-user_car-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_car`
--

/*!40000 ALTER TABLE `user_car` DISABLE KEYS */;
INSERT INTO `user_car` VALUES (1,1,1,5,15),(2,2,1,2,2),(3,3,1,5,10);
/*!40000 ALTER TABLE `user_car` ENABLE KEYS */;

--
-- Table structure for table `user_log`
--

DROP TABLE IF EXISTS `user_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_type` varchar(255) NOT NULL,
  `criticallity_level` int(11) NOT NULL,
  `currency_amount` int(11) NOT NULL,
  `event_text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_log`
--

/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` VALUES (1,'2018-10-05 09:06:09',1,'race_finish',2,2,'Окончание гонки');
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;

--
-- Table structure for table `winner`
--

DROP TABLE IF EXISTS `winner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `winner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contest_id` int(11) NOT NULL,
  `place` int(11) NOT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-winner-user_id` (`user_id`),
  KEY `idx-winner-contest_id` (`contest_id`),
  CONSTRAINT `fk-winner-contest_id` FOREIGN KEY (`contest_id`) REFERENCES `contest` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk-winner-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `winner`
--

/*!40000 ALTER TABLE `winner` DISABLE KEYS */;
INSERT INTO `winner` VALUES (183,1,5,434,'2018-10-09 07:06:45');
/*!40000 ALTER TABLE `winner` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-29 16:07:15
